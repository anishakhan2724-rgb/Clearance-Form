<?php
session_start();
require '../db.php';
if(!isset($_SESSION['admin_id'])){ header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
$stmt = $mysqli->prepare("SELECT * FROM clearances WHERE id=? LIMIT 1");
$stmt->bind_param('i',$id);
$stmt->execute();
$r = $stmt->get_result()->fetch_assoc();
if(!$r){ die('Not found'); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>View Request</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
body{
  font-family:'Inter',sans-serif;
  background: radial-gradient(circle at 20% 30%, rgba(0,255,255,0.15), transparent),
              radial-gradient(circle at 80% 70%, rgba(255,0,255,0.15), transparent),
              linear-gradient(135deg,#0a0f2d,#1a0541,#320a78);
  min-height:100vh;color:#fff;overflow:hidden;
}
/* 3D floating orbs */
.orb{
  position:absolute;border-radius:50%;filter:blur(60px);opacity:0.5;
  animation:float 12s infinite ease-in-out alternate;
}
.orb1{width:300px;height:300px;background:#6a00f4;top:-100px;left:-80px;}
.orb2{width:260px;height:260px;background:#00d4ff;bottom:-80px;right:-60px;}
@keyframes float{from{transform:translateY(0);}to{transform:translateY(40px);} }

/* Frosted glass card */
.card{
  background: rgba(255,255,255,0.07);
  border:1px solid rgba(255,255,255,0.18);
  box-shadow:0 0 40px rgba(0,0,0,0.4),0 0 20px rgba(0,200,255,0.2);
  backdrop-filter: blur(14px);
  border-radius:20px;
  overflow:hidden;
  transition:0.3s;
}
.card:hover{box-shadow:0 0 60px rgba(0,200,255,0.5),0 0 30px rgba(106,0,255,0.4);transform:translateY(-5px);}

/* Header */
.back-link{
  color:#00eaff !important;text-decoration:none;font-weight:500;
  transition:0.3s;
}
.back-link:hover{color:#6a00ff;text-shadow:0 0 6px #00eaff;}
.card-body h3{color:#00eaff;font-weight:600;}
.card-body p{color:#d0d0d0;}
.badge{font-size:0.9rem;font-weight:500;}

/* Form controls */
.form-control, textarea{
  background: rgba(255,255,255,0.08) !important;
  color: #fff !important;
  border: 1px solid rgba(255,255,255,0.25);
  border-radius:12px;
  padding:12px;
  transition:0.3s;
}
.form-control:focus, textarea:focus{
  border-color:#00eaff;
  box-shadow:0 0 12px rgba(0,234,255,0.6);
  background:rgba(255,255,255,0.12);
  color:#fff;
}

/* Buttons */
.btn-primary, .btn-success, .btn-danger{
  border:none;padding:0.6rem 1.6rem;border-radius:12px;font-weight:600;
  transition:0.3s;
  color:#fff;
}
.btn-primary{background:linear-gradient(135deg,#6a00ff,#00eaff);}
.btn-success{background:linear-gradient(135deg,#00ffb3,#00d4ff);}
.btn-danger{background:linear-gradient(135deg,#ff006e,#ff33a1);}
.btn-primary:hover, .btn-success:hover, .btn-danger:hover{
  transform:translateY(-3px);
  box-shadow:0 0 14px rgba(0,234,255,0.8),0 0 30px rgba(106,0,255,0.6);
}

/* Divider / HR */
hr.border-light{border-color:rgba(255,255,255,0.2);}
</style>
</head>
<body>
<div class="orb orb1"></div>
<div class="orb orb2"></div>

<div class="container py-4">
  <a href="dashboard.php" class="back-link"><i class="fa fa-arrow-left me-2"></i>Back</a>

  <div class="card mt-3">
    <div class="card-body">
      <h3 class="mb-3">Request #<?php echo $r['id']; ?> — <?php echo htmlspecialchars($r['name']); ?></h3>

      <p><strong>Email:</strong> <?php echo htmlspecialchars($r['email']); ?></p>
      <p><strong>Department:</strong> <?php echo htmlspecialchars($r['department']); ?></p>
      <p><strong>Purpose:</strong><br><?php echo nl2br(htmlspecialchars($r['purpose'])); ?></p>
      <p><strong>Submitted:</strong> <?php echo $r['created_at']; ?></p>

      <p><strong>Status:</strong>
        <span class="badge bg-<?php echo $r['status']=='approved'?'success':($r['status']=='rejected'?'danger':'secondary'); ?>">
          <?php echo $r['status']; ?>
        </span>
      </p>

      <form method="post" action="action.php?id=<?php echo $r['id']; ?>&act=note" class="mt-4">
        <label class="mb-1">Admin note (visible to user)</label>
        <textarea name="note" class="form-control" rows="3"><?php echo htmlspecialchars($r['admin_note']); ?></textarea>
        <button class="btn btn-primary mt-3"><i class="fa fa-save me-1"></i>Save Note</button>
      </form>

      <hr class="border-light">

      <?php if($r['status']=='pending'): ?>
        <a class="btn btn-success" href="action.php?id=<?php echo $r['id']; ?>&act=approve"><i class="fa fa-check me-1"></i>Approve</a>
        <a class="btn btn-danger ms-2" href="action.php?id=<?php echo $r['id']; ?>&act=reject"><i class="fa fa-times me-1"></i>Reject</a>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
