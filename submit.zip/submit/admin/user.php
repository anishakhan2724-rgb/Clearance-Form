<?php
session_start();
require '../db.php';
$success = '';
$errors = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $purpose = trim($_POST['purpose'] ?? '');

    // Basic validation
    if (!$name) $errors[] = 'Name is required.';
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (!$department) $errors[] = 'Department is required.';
    if (!$purpose) $errors[] = 'Purpose is required.';

    if (empty($errors)) {
        $stmt = $mysqli->prepare("INSERT INTO clearances (name,email,department,purpose,created_at,status) VALUES (?,?,?,?,NOW(),'pending')");
        $stmt->bind_param('ssss', $name, $email, $department, $purpose);
        if ($stmt->execute()) {
            $success = 'Your clearance request has been submitted successfully!';
        } else {
            $errors[] = 'Database error. Please try again.';
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Clearance Request Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
html, body {
  height: 100%;
  margin: 0;
  font-family:'Inter',sans-serif;
  background: radial-gradient(circle at 20% 30%, rgba(0,255,255,0.15), transparent),
              radial-gradient(circle at 80% 70%, rgba(255,0,255,0.15), transparent),
              linear-gradient(135deg,#0a0f2d,#1a0541,#320a78);
  color:#fff;
  overflow:auto;
  display:flex;
  justify-content:center;
  padding:20px;
}

/* Floating gradient orbs */
.orb{position:absolute;border-radius:50%;filter:blur(60px);opacity:0.5;animation:float 12s infinite ease-in-out alternate;}
.orb1{width:300px;height:300px;background:#6a00f4;top:-100px;left:-80px;}
.orb2{width:260px;height:260px;background:#00d4ff;bottom:-80px;right:-60px;}
@keyframes float{from{transform:translateY(0);}to{transform:translateY(40px);}}

/* Frosted Glass Form Card */
.form-card{
  width:100%;
  max-width:500px;
  background: rgba(255,255,255,0.07);
  border:1px solid rgba(255,255,255,0.18);
  box-shadow:0 0 40px rgba(0,0,0,0.4),0 0 20px rgba(0,200,255,0.2);
  backdrop-filter: blur(14px);
  border-radius:20px;
  overflow:hidden;
  padding:35px 30px;
  transition:0.3s;
  display:flex;
  flex-direction:column;
  max-height:90vh;
}
.form-card:hover{box-shadow:0 0 60px rgba(0,200,255,0.5),0 0 30px rgba(106,0,255,0.4);transform:translateY(-5px);}

/* Header */
.header{text-align:center;margin-bottom:20px;}
.header h2{font-weight:700;color:#00eaff;}
.header p{color:#d0d0d0;font-size:0.95rem;}

/* Form Content Scroll */
.form-content{
  overflow-y:auto;
  padding-right:10px;
}

/* Form Controls */
.form-label{color:#d8d8d8;font-weight:500;}
.form-control{
  border-radius:12px;padding:12px;font-size:15px;background:rgba(255,255,255,0.08);
  border:1px solid rgba(255,255,255,0.25);color:#fff;
  transition:0.3s;
}
.form-control:focus{
  border-color:#00eaff;box-shadow:0 0 12px rgba(0,234,255,0.6);
  background:rgba(255,255,255,0.12);color:#fff;
}

/* Buttons */
.btn-submit{
  width:100%;padding:14px;border:none;border-radius:12px;margin-top:15px;
  background:linear-gradient(135deg,#6a00ff,#00eaff);
  color:white;font-weight:600;font-size:16px;
  transition:0.3s;box-shadow:0 0 8px rgba(0,255,255,0.4);
}
.btn-submit:hover{
  transform:translateY(-4px);
  box-shadow:0 0 18px rgba(0,255,255,0.8),0 0 40px rgba(106,0,255,0.6);
}

/* Alerts */
.alert-success{background:rgba(0,255,255,0.1);border-left:4px solid #00eaff;color:#aaffff;border-radius:8px;}
.alert-danger{background:rgba(255,0,80,0.15);border-left:4px solid #ff2b7d;color:#ff73a6;border-radius:8px;}

/* Make form scrollable if screen is small */
@media(max-height:700px){
  .form-card{
    max-height:85vh;
  }
  .form-content{
    max-height:60vh;
  }
}
</style>
</head>
<body>

<div class="orb orb1"></div>
<div class="orb orb2"></div>

<div class="form-card">
  <div class="header">
    <h2>Clearance Request Form</h2>
    <p>Fill out the form below to submit your clearance request</p>
  </div>

  <?php if($success): ?>
    <div class="alert alert-success"><i class="fa fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?></div>
  <?php endif; ?>

  <?php if($errors): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php foreach($errors as $err): ?>
          <li><?php echo htmlspecialchars($err); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <div class="form-content">
  <form method="post">
    <div class="mb-3">
      <label class="form-label">Full Name</label>
      <input type="text" name="name" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Email Address</label>
      <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Department</label>
      <input type="text" name="department" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Purpose</label>
      <textarea name="purpose" class="form-control" rows="4" required></textarea>
    </div>

    <button class="btn-submit"><i class="fa fa-paper-plane me-2"></i>Submit Request</button>
  </form>
  </div>
</div>

</body>
</html>
