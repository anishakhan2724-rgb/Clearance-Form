<?php
$host = "localhost";
$user = "root";       // your DB username
$pass = "";           // your DB password
$db = "clearance_system";

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>
