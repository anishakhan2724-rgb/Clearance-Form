<?php
session_start();
require '../db.php';
if(!isset($_SESSION['admin_id'])){ header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
$act = $_GET['act'] ?? '';

if($act=='approve' || $act=='reject'){
    $status = $act=='approve' ? 'approved' : 'rejected';
    $stmt = $mysqli->prepare("UPDATE clearances SET status=? WHERE id=?");
    $stmt->bind_param('si',$status,$id);
    $stmt->execute();
    header('Location: dashboard.php');
    exit;
} elseif($act=='note' && $_SERVER['REQUEST_METHOD']=='POST'){
    $note = $_POST['note'] ?? '';
    $stmt = $mysqli->prepare("UPDATE clearances SET admin_note=? WHERE id=?");
    $stmt->bind_param('si',$note,$id);
    $stmt->execute();
    header('Location: view.php?id='.$id);
    exit;
} else {
    die('Invalid action');
}
?>