<?php
session_start();
require '../db.php';
$err = '';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $email = $_POST['email'] ?? '';
    $pass = $_POST['password'] ?? '';

    // Fetch user by email
    $stmt = $mysqli->prepare("SELECT id,email,password,name FROM admins WHERE email=? LIMIT 1");
    $stmt->bind_param('s',$email);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();

    if($res){
        // Check if password is hashed (starts with $2y$ for bcrypt)
        if(str_starts_with($res['password'], '$2y$')){
            // Use secure password_verify
            if(password_verify($pass, $res['password'])){
                $_SESSION['admin_id'] = $res['id'];
                $_SESSION['admin_name'] = $res['name'];
                header('Location: dashboard.php');
                exit;
            } else {
                $err = 'Invalid credentials';
            }
        } else {
            // If password is plain text, verify manually and hash it
            if($pass === $res['password']){
                // Update database with hashed password
                $hashed = password_hash($pass, PASSWORD_DEFAULT);
                $update = $mysqli->prepare("UPDATE admins SET password=? WHERE id=?");
                $update->bind_param('si', $hashed, $res['id']);
                $update->execute();

                $_SESSION['admin_id'] = $res['id'];
                $_SESSION['admin_name'] = $res['name'];
                header('Location: dashboard.php');
                exit;
            } else {
                $err = 'Invalid credentials';
            }
        }
    } else {
        $err = 'Invalid credentials';
    }
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Login - Clearance Management</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
body{
  font-family:'Inter',sans-serif;
  background: radial-gradient(circle at 20% 30%, rgba(0,255,255,0.25), transparent),
              radial-gradient(circle at 80% 70%, rgba(255,0,255,0.25), transparent),
              linear-gradient(135deg,#0a0f2d,#1a0541,#320a78);
  background-size:cover;
  min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;
  overflow:hidden;color:#fff;
}

/* 3D floating gradient orbs */
.orb{
  position:absolute;border-radius:50%;filter:blur(60px);opacity:0.6;
  animation:float 10s infinite ease-in-out alternate;
}
.orb1{width:300px;height:300px;background:#6a00f4;top:-80px;left:-60px;animation-duration:12s;}
.orb2{width:260px;height:260px;background:#00d4ff;bottom:-60px;right:-40px;animation-duration:14s;}
@keyframes float{from{transform:translateY(0);}to{transform:translateY(40px);} }

/* Frosted Glass Neon Card */
.login-card{
  width:100%;max-width:420px;
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.07);
  border-radius:20px;
  border:1px solid rgba(255,255,255,0.18);
  box-shadow:0 0 40px rgba(0,0,0,0.4), 0 0 20px rgba(0,200,255,0.3);
  overflow:hidden;
  animation:fadeIn .8s ease;
}
@keyframes fadeIn{from{opacity:0;transform:translateY(25px);}to{opacity:1;} }

/* Glossy header */
.header{
  text-align:center;padding:45px 20px;position:relative;color:white;
  background:linear-gradient(135deg,#5a00f0,#8400ff,#00d2ff);
  box-shadow:inset 0 0 30px rgba(255,255,255,0.25);
}
.header::after{
  content:'';position:absolute;inset:0;
  background:linear-gradient(145deg,rgba(255,255,255,0.15),transparent);
  mix-blend-mode:overlay;
}
.logo-icon{
  width:70px;height:70px;border-radius:18px;background:rgba(255,255,255,0.18);
  display:flex;align-items:center;justify-content:center;font-size:2rem;margin:0 auto;
  backdrop-filter:blur(4px);
}

/* Glowing Inputs */
.card-body{padding:38px 32px;color:white;}
.form-label{color:#d8d8d8;font-weight:500;}
.form-control{
  border-radius:12px;padding:14px;font-size:15px;background:rgba(255,255,255,0.09);
  border:1px solid rgba(255,255,255,0.2);color:#fff;
}
.form-control:focus{
  border-color:#00eaff;box-shadow:0 0 12px rgba(0,234,255,0.6);
  background:rgba(255,255,255,0.15);
}

/* Neon Pulse Button */
.btn-login{
  width:100%;padding:14px;border:none;border-radius:12px;margin-top:10px;
  background:linear-gradient(135deg,#6a00ff,#00eaff);
  color:white;font-weight:600;font-size:16px;
  transition:0.3s;box-shadow:0 0 8px rgba(0,255,255,0.4);
}
.btn-login:hover{
  transform:translateY(-4px);
  box-shadow:0 0 18px rgba(0,255,255,0.8),0 0 40px rgba(106,0,255,0.6);
}

/* Error alert */
.alert-danger{
  background:rgba(255,0,80,0.15);
  border-left:4px solid #ff2b7d;color:#ff73a6;
  border-radius:8px;
}
.password-toggle{
  position:absolute;right:12px;top:50%;transform:translateY(-50%);
  border:none;background:none;color:#ccc;cursor:pointer;
}
</style>
</head>
<body>
<div class="orb orb1"></div>
<div class="orb orb2"></div>

<div class="login-card">
  <div class="header">
    <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
    <h2 class="mt-3">Admin Login</h2>
    <p>Clearance Management System</p>
  </div>

  <div class="card-body">
    <?php if($err): ?>
      <div class="alert alert-danger"><i class="fa fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($err); ?></div>
    <?php endif; ?>

    <form method="post">
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required>
      </div>

      <div class="mb-3 position-relative">
        <label class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
        <button type="button" class="password-toggle" onclick="togglePassword()"><i class="fa fa-eye"></i></button>
      </div>

      <button class="btn-login"><i class="fa fa-sign-in-alt me-2"></i>Login</button>
    </form>

    <a href="../index.php" class="d-block text-center mt-3 text-decoration-none" style="color:#aeeaff;">
      <i class="fa fa-arrow-left me-1"></i>Back to Public Form
    </a>
  </div>
</div>

<script>
function togglePassword(){
  const input=document.getElementById('password');
  const icon=document.querySelector('.password-toggle i');
  if(input.type==='password'){ input.type='text'; icon.classList.replace('fa-eye','fa-eye-slash'); }
  else{ input.type='password'; icon.classList.replace('fa-eye-slash','fa-eye'); }
}
</script>
</body>
</html>
