<?php
session_start();
require '../db.php';
if(!isset($_SESSION['admin_id'])){ header('Location: login.php'); exit; }
$stmt = $mysqli->query("SELECT * FROM clearances ORDER BY created_at DESC");
$rows = $stmt->fetch_all(MYSQLI_ASSOC);
$total = $mysqli->query("SELECT COUNT(*) as count FROM clearances")->fetch_assoc()['count'];
$pending = $mysqli->query("SELECT COUNT(*) as count FROM clearances WHERE status='pending'")->fetch_assoc()['count'];
$approved = $mysqli->query("SELECT COUNT(*) as count FROM clearances WHERE status='approved'")->fetch_assoc()['count'];
$rejected = $mysqli->query("SELECT COUNT(*) as count FROM clearances WHERE status='rejected'")->fetch_assoc()['count'];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
body {
  font-family: "Poppins", sans-serif;
  background: radial-gradient(circle at top left, #3d1f99, #0a0a0f);
  color: #fff;
  overflow-x: hidden;
}
.sidebar {
  background: linear-gradient(180deg,#0f0c29,#302b63,#24243e);
  min-height: 100vh;
  padding: 20px;
  box-shadow: 0 0 25px rgba(0,0,0,0.5);
  border-right: 2px solid rgba(255,255,255,0.1);
}
.sidebar a {
  color: #cfd1ff;
  display: block;
  padding: 12px 15px;
  border-radius: 10px;
  margin-bottom: 8px;
  transition: 0.3s;
  font-weight: 500;
}
.sidebar a:hover, .sidebar a.active {
  background: linear-gradient(90deg,#7b2ff7,#f107a3);
  color: #fff;
  transform: translateX(8px);
  box-shadow: 0 5px 20px rgba(241,7,163,0.5);
}
.user-avatar {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: linear-gradient(135deg,#7b2ff7,#f107a3);
  display: flex;
  justify-content: center;
  align-items: center;
  color: #fff;
  font-size: 20px;
  font-weight: bold;
  box-shadow: 0 0 15px rgba(255,0,200,0.7);
}
.main-content {
  padding: 25px;
  animation: fade 0.7s ease-in-out;
}
@keyframes fade { from {opacity:0; transform: translateY(20px);} to{opacity:1;} }
.stat-card {
  padding: 25px;
  border-radius: 18px;
  background: rgba(255,255,255,0.08);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255,255,255,0.1);
  transition: 0.3s;
}
.stat-card:hover {
  transform: scale(1.05) translateY(-5px);
  box-shadow: 0 15px 40px rgba(0,0,0,0.4);
}
.table-container {
  padding: 20px;
  border-radius: 20px;
  background: rgba(255,255,255,0.1);
  backdrop-filter: blur(8px);
}
.table tbody tr:hover {
  background: rgba(255,255,255,0.15) !important;
  transform: scale(1.01);
}
.btn-custom {
  background: linear-gradient(135deg,#7b2ff7,#f107a3);
  border:none;
  color:#fff;
  border-radius:10px;
}
.btn-custom:hover {
  transform: scale(1.05);
  box-shadow: 0 0 20px rgba(241,7,163,0.7);
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-lg-2 sidebar">
  <div class="d-flex align-items-center mb-4">
    <div class="user-avatar me-3"><?php echo strtoupper(substr($_SESSION['admin_name'],0,1)); ?></div>
    <div>
      <h5><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h5>
      <small>Administrator</small>
    </div>
  </div>
  <a class="active" href="#"><i class="fa fa-gauge me-2"></i>Dashboard</a>
  <a href="user.php"><i class="fa fa-users me-2"></i>Users</a>
  <a href="settings.php"><i class="fa fa-cog me-2"></i>Settings</a>
  <a href="#"><i class="fa fa-chart-line me-2"></i>Reports</a>
  <a href="logout.php" class="text-danger"><i class="fa fa-right-from-bracket me-2"></i>Logout</a>
</div>

<div class="col-lg-10 main-content">
  <h2 class="fw-bold mb-4">Dashboard Overview</h2>

  <div class="row g-4 mb-4">
    <div class="col-md-3"><div class="stat-card"><h6>Total Requests</h6><h2><?php echo $total; ?></h2></div></div>
    <div class="col-md-3"><div class="stat-card"><h6>Pending</h6><h2><?php echo $pending; ?></h2></div></div>
    <div class="col-md-3"><div class="stat-card"><h6>Approved</h6><h2><?php echo $approved; ?></h2></div></div>
    <div class="col-md-3"><div class="stat-card"><h6>Rejected</h6><h2><?php echo $rejected; ?></h2></div></div>
  </div>

  <div class="table-container">
    <h4 class="mb-3">Clearance Requests</h4>
    <div class="table-responsive">
      <table class="table table-dark table-hover align-middle">
        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Department</th><th>Purpose</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach($rows as $r): ?>
        <tr>
          <td>#<?php echo $r['id']; ?></td>
          <td><?php echo htmlspecialchars($r['name']); ?></td>
          <td><?php echo htmlspecialchars($r['email']); ?></td>
          <td><?php echo htmlspecialchars($r['department']); ?></td>
          <td><?php echo htmlspecialchars(substr($r['purpose'],0,50)); ?></td>
          <td><?php echo ucfirst($r['status']); ?></td>
          <td><a href="view.php?id=<?php echo $r['id']; ?>" class="btn btn-custom btn-sm"><i class="fa fa-eye"></i></a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
