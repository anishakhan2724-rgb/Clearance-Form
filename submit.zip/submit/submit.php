<?php
require 'db.php';

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$department = trim($_POST['department'] ?? '');
$purpose = trim($_POST['purpose'] ?? '');

if(!$name || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die('Invalid input. Please go back and complete required fields.');
}

$stmt = $mysqli->prepare("INSERT INTO clearances (name,email,department,purpose) VALUES (?,?,?,?)");
$stmt->bind_param('ssss', $name, $email, $department, $purpose);
if($stmt->execute()){
    $id = $stmt->insert_id;
    header('Location: index.php?success='.$id);
    exit;
} else {
    die('Database error: '.$mysqli->error);
}
?>