Clearance System — XAMPP-ready
=================================

What this is
-------------
A simple digital clearance form website built with PHP + MySQL intended to run under XAMPP.
Features:
- Student/employee fills a clearance form (name, email, department, purpose, attachments optional).
- Admin logs in, sees pending requests, views details, approves or rejects.
- Status updates shown to users.
- SQL file provided to create database and seed an admin account.

How to install (XAMPP)
-----------------------
1. Start Apache and MySQL from XAMPP control panel.
2. Copy the 'clearance_system' folder into XAMPP's htdocs directory (e.g., C:\xampp\htdocs\clearance_system).
3. Import the SQL file:
   - Open phpMyAdmin (http://localhost/phpmyadmin).
   - Create a new database named `clearance_system` OR import the provided `database.sql` directly.
   - If creating manually, run: IMPORT -> select /database.sql (it creates database and tables).
4. Edit `admin/config.php` if you change DB credentials (default expects root with no password).
5. Visit the site:
   - Public form: http://localhost/clearance_system/index.php
   - Admin login: http://localhost/clearance_system/admin/login.php
6. Default admin credentials:
   - Email: admin@example.com
   - Password: Admin@123

Security notes
--------------
- This is an educational demo. For production, add stronger authentication, password hashing with salts, CSRF protection, input validation, file upload protections, HTTPS, and rate limiting.
- Change default admin password immediately.

