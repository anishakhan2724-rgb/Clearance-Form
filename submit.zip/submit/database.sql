
-- SQL dump for Clearance System
CREATE DATABASE IF NOT EXISTS `clearance_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `clearance_system`;

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT 'Administrator',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `clearances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `department` varchar(255) DEFAULT NULL,
  `purpose` text,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `admin_note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin: password is plaintext here but the PHP uses password_hash to validate if you re-create.
-- For simplicity we store a bcrypt hash generated for "Admin@123".
INSERT INTO `admins` (`email`,`password`,`name`) VALUES
('amna@gmail.com','123','Administrator');

-- Optional sample clearance
INSERT INTO `clearances` (`name`,`email`,`department`,`purpose`) VALUES
('John Doe','john@example.com','Engineering','Clearance for graduation - equipment returned');
