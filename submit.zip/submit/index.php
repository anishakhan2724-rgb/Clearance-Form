<!-- FULL ALL-IN-ONE MODERN ANIMATED UI APPLIED — PHP KEPT 100% INTACT -->
<?php
require 'db.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Clearance Request - Professional Portal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- External Libraries -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- ALL-IN-ONE UI THEME (Neon + Glassmorphism + 3D Cards + Animated Background) -->
  <style>
    :root {
      --primary: #6a5af9;
      --primary-dark: #4b3ee4;
      --neon: #00eaff;
      --danger: #ff4f81;
      --success: #2ee59d;
      --warning: #ffb200;
      --light: #ffffff;
      --dark: #111;
      --glass-bg: rgba(255, 255, 255, 0.15);
      --glass-border: rgba(255, 255, 255, 0.35);
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Inter', sans-serif;
      background: radial-gradient(circle at top left, #1b1b2f, #0f0f17);
      min-height: 100vh;
      color: #e4e4e4;
      overflow-x: hidden;
    }

    /* Animated background orbs */
    .orb {
      position: fixed;
      width: 300px;
      height: 300px;
      border-radius: 50%;
      filter: blur(90px);
      opacity: 0.4;
      animation: floatOrb 20s infinite alternate ease-in-out;
      z-index: -1;
    }
    .orb-1 { background: #6a5af9; top: 10%; left: 5%; }
    .orb-2 { background: #00eaff; bottom: 10%; right: 5%; animation-duration: 26s; }
    @keyframes floatOrb {
      0% { transform: translate(0,0) scale(1); }
      100% { transform: translate(60px, -40px) scale(1.2); }
    }

    /* Glass container */
    .form-container {
      backdrop-filter: blur(18px);
      background: var(--glass-bg);
      border: 1px solid var(--glass-border);
      border-radius: 18px;
      padding: 2rem;
      margin-top: 3rem;
      box-shadow: 0 20px 60px rgba(0,0,0,0.4);
      animation: fadeIn 1.2s ease;
    }
    @keyframes fadeIn { from {opacity:0; transform: translateY(20px);} to {opacity:1;} }

    /* Neon header */
    .form-header {
      text-align: center;
      padding-bottom: 2rem;
    }
    .form-title {
      font-size: 2rem;
      color: var(--neon);
      text-shadow: 0 0 10px var(--neon);
      font-weight: 700;
    }
    .form-subtitle {
      opacity: 0.8;
      font-size: 0.95rem;
    }

    /* Inputs */
    .input-group-text {
      background: rgba(255,255,255,0.07);
      border: 1px solid rgba(255,255,255,0.2);
      color: var(--neon);
    }
    .form-control {
      background: rgba(255,255,255,0.07);
      border: 1px solid rgba(255,255,255,0.25);
      color: white;
    }
    .form-control:focus {
      border-color: var(--neon);
      box-shadow: 0 0 10px var(--neon);
    }

    /* Buttons */
    .btn-primary {
      background: linear-gradient(135deg, var(--primary), var(--primary-dark));
      border: none;
      color: white;
      padding: 0.7rem 2rem;
      border-radius: 10px;
      font-weight: 600;
      box-shadow: 0 0 12px rgba(106,90,249,0.8);
      transition: 0.3s;
    }
    .btn-primary:hover {
      transform: translateY(-3px);
      box-shadow: 0 0 18px var(--neon);
    }

    .btn-link { color: var(--neon); text-decoration: none; }

    /* Status card */
    .status-card {
      background: rgba(255,255,255,0.05);
      border-left: 4px solid var(--neon);
      padding: 1.5rem;
      border-radius: 12px;
    }

    /* Steps */
    .step-indicator { display:flex; justify-content:space-between; margin:2rem 0; }
    .step-circle {
      width: 38px; height: 38px;
      border-radius: 50%;
      border: 2px solid var(--neon);
      display:flex; align-items:center; justify-content:center;
      color: var(--neon);
      transition: 0.3s;
    }
    .step.active .step-circle {
      background: var(--neon);
      color: black;
      box-shadow: 0 0 12px var(--neon);
    }

    /* Features */
    .feature-icon {
      background: rgba(255,255,255,0.05);
      border-radius: 12px;
      padding: 1rem;
      font-size: 1.4rem;
      color: var(--neon);
      box-shadow: 0 0 12px rgba(0,234,255,0.4);
    }
  </style>
</head>
<body>

<!-- ANIMATED ORBS -->
<div class="orb orb-1"></div>
<div class="orb orb-2"></div>

<div class="container">
  <div class="form-container">

    <!-- HEADER -->
    <div class="form-header">
      <h1 class="form-title">Clearance Request Form</h1>
      <p class="form-subtitle">Submit your official clearance request for processing</p>
    </div>

    <!-- PHP STATUS (KEPT 100% SAME) -->
    <?php if(isset($_GET['id'])): 
      $id = intval($_GET['id']);
      $stmt = $mysqli->prepare("SELECT id,name,email,department,purpose,status,created_at,admin_note FROM clearances WHERE id=?");
      $stmt->bind_param('i',$id);
      $stmt->execute();
      $res = $stmt->get_result()->fetch_assoc();
      if($res): ?>

        <div class="status-card mb-4">
          <h5 class="mb-2"><i class="fas fa-search me-2"></i>Request Status</h5>
          <p><strong>Status:</strong>
            <span class="badge bg-<?php echo $res['status']=='approved'?'success':($res['status']=='rejected'?'danger':'warning'); ?>">
              <?php echo htmlspecialchars(ucfirst($res['status'])); ?>
            </span>
          </p>
          <p><strong>Submitted:</strong> <?php echo htmlspecialchars($res['created_at']); ?></p>
          <?php if($res['admin_note']): ?>
            <p><strong>Admin Note:</strong></p>
            <div class="alert alert-light bg-transparent border-white text-white">
              <?php echo nl2br(htmlspecialchars($res['admin_note'])); ?>
            </div>
          <?php endif; ?>
        </div>

    <?php else: ?>
      <div class="alert alert-warning bg-transparent text-warning border-warning">
        Request not found.
      </div>
    <?php endif; endif; ?>


    <!-- SUCCESS MESSAGE -->
    <?php if(isset($_GET['success'])): ?>
    <div class="alert alert-success bg-transparent text-success border-success">
      <strong>Request Submitted Successfully!</strong><br>
      Your request ID is <strong>#<?php echo intval($_GET['success']); ?></strong>
    </div>
    <?php endif; ?>


    <!-- STEPS -->
    <div class="step-indicator">
      <div class="step active"><div class="step-circle">1</div><small>Details</small></div>
      <div class="step"><div class="step-circle">2</div><small>Review</small></div>
      <div class="step"><div class="step-circle">3</div><small>Submit</small></div>
    </div>


    <!-- FORM (PHP action unchanged) -->
    <form method="post" action="submit.php" id="clearanceForm">

      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Full Name *</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input name="name" required class="form-control" placeholder="Enter your name">
          </div>
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label">Email *</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input name="email" type="email" required class="form-control" placeholder="you@example.com">
          </div>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Department</label>
        <div class="input-group">
          <span class="input-group-text"><i class="fas fa-building"></i></span>
          <input name="department" class="form-control" placeholder="e.g. HR, IT, Finance">
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Purpose *</label>
        <div class="input-group">
          <span class="input-group-text"><i class="fas fa-edit"></i></span>
          <textarea name="purpose" required class="form-control" rows="4"></textarea>
        </div>
      </div>

      <div class="d-flex justify-content-between align-items-center mt-4">
        <button class="btn-primary" type="submit">
          <i class="fas fa-paper-plane me-1"></i>Submit
        </button>
        <a href="admin/login.php" class="btn-link"><i class="fas fa-lock me-1"></i>Admin Login</a>
      </div>

    </form>

  </div>
</div>

</body>
</html>